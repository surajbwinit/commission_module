@echo off
echo Starting Commission web app...
set NODE_ENV=production
if "%PORT%"=="" set PORT=3000
node server.js
pause
