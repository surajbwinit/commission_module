# Commission Web — Production Build

API baked in at build time: `https://commission-dev-api.winitsoftware.com/api`

## Run
```bash
./start.sh      # Linux / macOS
start.bat       # Windows
```

Then open http://localhost:3000

## Change the API URL
The API URL is compiled into the browser bundle. Editing the `.env` file
will NOT change it. To switch endpoints, rebuild:
```bash
./build-standalone.sh https://my-new-api.example.com/api
```

## Requirements
- Node.js 18+
- Port 3000 free (or set `PORT` in `.env`)
