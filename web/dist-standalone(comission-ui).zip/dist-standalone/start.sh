#!/bin/bash
echo "🚀 Starting Commission web app..."
PORT=${PORT:-3000}
NODE_ENV=production node server.js
